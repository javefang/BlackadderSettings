#!/bin/bash
CLICK_PREFIX="click"
CLICK_ANDROID="/data/click"

# uploading click/blackadder binary and libraries
adb push $CLICK_PREFIX $CLICK_ANDROID

# create blackadder settings directory
adb shell mkdir /sdcard/blackadder

